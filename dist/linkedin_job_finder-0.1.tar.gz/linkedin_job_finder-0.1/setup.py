from setuptools import setup, find_packages

setup(
    name='linkedin_job_finder',
    version='0.1',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'linkedin_job_helper = linkedin_job_helper.app_gui_class:main',
        ],
    }
)